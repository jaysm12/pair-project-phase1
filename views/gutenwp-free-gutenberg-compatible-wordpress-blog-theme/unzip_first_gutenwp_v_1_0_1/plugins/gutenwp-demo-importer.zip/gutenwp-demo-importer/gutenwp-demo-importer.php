<?php
/**
 * Plugin Name: Gutenwp Demo Importer
 * Plugin URI: http://www.themeum.com
 * Description: Themeum Demo Importer is ultimate Gutenwp plugins
 * Author: Themeum
 * Version: 1.0
 * Author URI: http://www.themeum.com
 *
 * Tested up to: 1.0
 * Text Domain: Gutenwp
 *
 * @package Themeum
 * @category Core
 * @author Gutenwp
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; # Exit if accessed directly
}
include_once( 'framework.php' );
include_once( 'import-functions.php' );
include_once( 'sample-config.php' );

