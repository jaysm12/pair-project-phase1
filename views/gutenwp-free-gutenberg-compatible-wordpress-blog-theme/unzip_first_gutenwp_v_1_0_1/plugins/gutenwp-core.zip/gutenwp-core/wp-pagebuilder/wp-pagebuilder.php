<?php
if ( ! defined( 'ABSPATH' ) ) exit; # Exit if accessed directly

# Addon Generate.
add_filter( 'wppb_available_addons', 'gutenwp_addons_function' );
if ( ! function_exists('gutenwp_addons_function')){
  function gutenwp_addons_function($addons){
      $addons[] = 'Themeum_Title_Addon'; 
      $addons[] = 'Gutenwp_Post_Slider';
      $addons[] = 'Gutenwp_Latest_Post';
      $addons[] = 'Gutenwp_Music_Post';
      $addons[] = 'Gutenwp_Category_List';
      $addons[] = 'gutenwp_featured_post';
      $addons[] = 'Gutenwp_PDF_Book_Addon';
      $addons[] = 'Gutenwp_Post_Slider2';
      $addons[] = 'Gutenwp_Image';
      
      return $addons;
  }
}

# Addons list.
require_once plugin_dir_path( __FILE__ ). 'themeum-title.php';
require_once plugin_dir_path( __FILE__ ). 'gutenwp-slider.php';
require_once plugin_dir_path( __FILE__ ). 'gutenwp-post-slider.php';
require_once plugin_dir_path( __FILE__ ). 'gutenwp-category.php';
require_once plugin_dir_path( __FILE__ ). 'gutenwp-music-post.php';
require_once plugin_dir_path( __FILE__ ). 'gutenwp-latest-post.php';
require_once plugin_dir_path( __FILE__ ). 'gutenwp-fetured-post.php';
require_once plugin_dir_path( __FILE__ ). 'gutenwp-books.php';
require_once plugin_dir_path( __FILE__ ). 'gutenwp-image.php';
