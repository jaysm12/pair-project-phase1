=== gutenwp ===
Version: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==
Gutenwp is a beautiful, responsive and versatile blog theme for WordPress websites to showcase all your blogs. Built with Gutenberg and the popular plugin WP Page Builder, this blog theme allows creative display of blogs. There’s something for every blogger here which comes with four home variations- the default creative blog, food blog, lifestyle blog and personal blog. The theme comes with a compact navigation system, stunning typography, multi-column layout and minimalist classic designs. You can make your blog super popular with the easy social media integration in this translation-ready theme to reach out to readers everywhere!